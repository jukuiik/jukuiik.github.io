<?php

/**
 * Change this token with your bot token. You can get it from @botfather (https://t.me/botfather)
 * also change this chat_id with your chat_id. To get your chat_id, you can
 * use @id_chat_bot (https://t.me/id_chat_bot) in telegram. DONT FORGET TO START THE BOT.   
 */
$config = [
    'telegram_bot_token' => '6282537218:AAGZFD2Q03Z5054qLsHJ_WrpOcbpr2fFNZs',
    'chat_id'            => 5906328714
];